THE LEGACY KEEPERS — static site build
=====================================

Login credentials:
  Membership ID : Q-T-971
  Password      : COVENANT

HOW TO VIEW IT
--------------
The assets use absolute paths (/_next/...), so the folder must be SERVED
from the root of a domain/subdomain. Opening index.html with file://
will NOT work.

Easiest way to try it locally:
    cd this-folder
    python3 -m http.server 8080
then open  http://localhost:8080

HOW TO PUBLISH
--------------
Upload the entire contents of this folder to the ROOT of any static host:
Netlify, Vercel, Cloudflare Pages, cPanel public_html, an S3 bucket, etc.
No build step, no database, no server-side code is required.

NOTES
-----
- The site ships with bundled demo data; it does not need PostgreSQL.
- Fonts are self-hosted (no Google Fonts request at runtime).
- Build date: 2026-08-29
